import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np

class ConvBlock(torch.nn.Module):
    def __init__(self, input_size, output_size, kernel_size, stride, padding,   dilation=1, bias=True, isuseBN=True, groups=1):
        super(ConvBlock, self).__init__()
        self.padding = padding
        self.isuseBN = isuseBN
        if self.padding == 0:
            self.conv = torch.nn.Conv2d(input_size, output_size, kernel_size, stride, padding=0,  dilation=1, bias=bias, groups=groups)
        else:
            self.conv = nn.Sequential(
                nn.ReflectionPad2d(padding),
                torch.nn.Conv2d(input_size, output_size, kernel_size, stride, padding=0,  dilation=dilation, bias=bias, groups=groups)
            )
        if self.isuseBN:
            self.bn = nn.InstanceNorm2d(output_size)
        self.act = nn.LeakyReLU(True)

    def forward(self, x):
        out = self.conv(x)
        if self.isuseBN:
            out = self.bn(out)
        out = self.act(out)
        return out

class Attention(nn.Module):

    def forward(self, query, key, value):
        scores = torch.matmul(query, key.transpose(-2, -1)
                              ) / math.sqrt(query.size(-1))
        p_attn = F.softmax(scores, dim=-1)
        p_val = torch.matmul(p_attn, value)
        return p_val, p_attn

class MultiHeadedAttention(nn.Module):

    def __init__(self, patchsize, d_model):
        super().__init__()
        self.patchsize = patchsize
        self.query_embedding = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.value_embedding = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.key_embedding = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.output_linear = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(d_model, d_model, kernel_size=3, padding=0),
            nn.LeakyReLU(0.2, inplace=True))
        self.attention = Attention()

    def forward(self, x, x1, c):
        b, _, h, w = x.size()
        d_k = c // len(self.patchsize)
        output = []
        _query = self.query_embedding(x)

        _key = self.key_embedding(x1)
        _value = self.value_embedding(x1)

        for (width, height), query, key, value in zip(self.patchsize,
                                                      torch.chunk(_query, len(self.patchsize), dim=1), torch.chunk(
                    _key, len(self.patchsize), dim=1),
                                                      torch.chunk(_value, len(self.patchsize), dim=1)):
            out_w, out_h = w // width, h // height
            query = query.view(b, d_k, out_h, height, out_w, width)
            query = query.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            key = key.view(b, d_k, out_h, height, out_w, width)
            key = key.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            value = value.view(b, d_k, out_h, height, out_w, width)
            value = value.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            y, _ = self.attention(query, key, value)
            y = y.view(b, out_h, out_w, d_k, height, width)
            y = y.permute(0, 3, 1, 4, 2, 5).contiguous().view(b, d_k, h, w)
            output.append(y)
        output = torch.cat(output, 1)
        x = self.output_linear(output)
        return x

class FeedForward(nn.Module):
    def __init__(self, d_model):
        super(FeedForward, self).__init__()
        self.conv = nn.Sequential(
            nn.ReflectionPad2d(2),
            nn.Conv2d(d_model, d_model, kernel_size=3, padding=0, dilation=2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(d_model, d_model, kernel_size=3, padding=0),
            nn.LeakyReLU(0.2, inplace=True))

    def forward(self, x):
        x = self.conv(x)
        return x

class TransformerBlock(nn.Module):
    def __init__(self, patchsize, hidden=128):
        super().__init__()
        self.attention = MultiHeadedAttention(patchsize, d_model=hidden)
        self.feed_forward = FeedForward(hidden)

    def forward(self, q, kv, c):
        q = q + self.attention(q, kv, c)
        q = q + self.feed_forward(q)
        return q

class CrossMultiHeadedAttention(nn.Module):
    def __init__(self, patchsize, d_model):
        super().__init__()
        self.patchsize = patchsize
        self.query_embedding1 = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.query_embedding2 = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.value_embedding = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.key_embedding = nn.Conv2d(
            d_model, d_model, kernel_size=1, padding=0)
        self.output_linear = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(d_model*2, d_model, kernel_size=3, padding=0),
            nn.LeakyReLU(0.2, inplace=True))

        self.attention1 = Attention()
        self.attention2 = Attention()

    def forward(self, pan, ms, gt, c):
        b, _, h, w = gt.size()
        d_k = c // len(self.patchsize)
        output1 = []
        output2 = []
        _query1 = self.query_embedding1(pan)
        _query2 = self.query_embedding2(ms)

        _key = self.key_embedding(gt)
        _value = self.value_embedding(gt)

        for (width, height), query1, query2, key, value in zip(self.patchsize,
                                                               torch.chunk(_query1, len(self.patchsize), dim=1),
                                                               torch.chunk(_query2, len(self.patchsize), dim=1),
                                                               torch.chunk(_key, len(self.patchsize), dim=1),
                                                               torch.chunk(_value, len(self.patchsize), dim=1)):
            out_w, out_h = w // width, h // height
            query1 = query1.view(b, d_k, out_h, height, out_w, width)
            query1 = query1.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            query2 = query2.view(b, d_k, out_h, height, out_w, width)
            query2 = query2.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            key = key.view(b, d_k, out_h, height, out_w, width)
            key = key.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            value = value.view(b, d_k, out_h, height, out_w, width)
            value = value.permute(0, 2, 4, 1, 3, 5).contiguous().view(
                b, out_h * out_w, d_k * height * width)
            y1, _ = self.attention1(query1, key, value)
            y2, _ = self.attention2(query2, key, value)
            y1 = y1.view(b, out_h, out_w, d_k, height, width)
            y1 = y1.permute(0, 3, 1, 4, 2, 5).contiguous().view(b, d_k, h, w)
            output1.append(y1)
            y2 = y2.view(b, out_h, out_w, d_k, height, width)
            y2 = y2.permute(0, 3, 1, 4, 2, 5).contiguous().view(b, d_k, h, w)
            output2.append(y2)
        output1 = torch.cat(output1, 1)
        output2 = torch.cat(output2, 1)
        output = self.output_linear(torch.cat([output1, output2], 1))
        return output

class TForwardBlock(nn.Module):

    def __init__(self, patchsize, hidden=128):
        super().__init__()
        self.attention = CrossMultiHeadedAttention(patchsize, d_model=hidden)
        self.feed_forward1 = FeedForward(hidden)
        self.feed_forward2 = FeedForward(hidden)

    def forward(self, pan, ms, gt, c):
        gt = pan + ms + self.attention(pan, ms, gt, c)
        gt = gt + self.feed_forward1(gt)
        return gt

def split_layer(total_channels, num_groups):
    split = [int(np.ceil(total_channels / num_groups)) for _ in range(num_groups)]
    split[num_groups - 1] += total_channels - sum(split)
    return split

class Siamtrans(nn.Module):
    def __init__(self, channel, patchsize):
        super(Siamtrans, self).__init__()
        self.tfans_pan_real = TransformerBlock(patchsize, hidden=channel)
        self.tfans_pan_fake = TransformerBlock(patchsize, hidden=channel//2)
        self.tfans_ms_real = TransformerBlock(patchsize, hidden=channel)
        self.tfans_ms_fake = TransformerBlock(patchsize, hidden=channel//2)
        self.tforward = TForwardBlock(patchsize, hidden=channel//2)

    def forward(self, pan1, pan2, ms1, ms2, pan, ms):

        gt1 = 0.5*(pan2+ms2)
        _, c, h, w = pan1.size()
        pan_real = self.tfans_pan_real(pan, pan, c*2)
        ms_real = self.tfans_ms_real(ms, ms, c*2)
        pan_fake = self.tfans_pan_fake(pan1, ms2, c)
        ms_fake = self.tfans_ms_fake(ms1, pan2, c)
        gt_fuse = self.tforward(pan1, ms1, gt1, c)
        return pan_real, pan_fake, ms_real, ms_fake, gt_fuse

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        if kernel_size == 1:
            self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,
                          dilation=dilation, bias=False)
        else:
            self.conv = nn.Sequential(
                nn.ReflectionPad2d(1),
                nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, bias=False)
            )
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.relu(x)
        return x

class deconv(nn.Module):
    def __init__(self, input_channel, output_channel, kernel_size, padding, factor, bias=True):
        super().__init__()
        self.factor = factor
        self.conv = nn.Sequential(
                nn.ReflectionPad2d(padding),
                nn.Conv2d(input_channel, output_channel, kernel_size, stride=1, padding=0, bias=bias)
        )

    def forward(self, x):
        x = F.interpolate(x, scale_factor=self.factor, mode='bilinear', align_corners=True)
        return self.conv(x)

class deconv2(nn.Module):
    def __init__(self, input_channel, kernel_size, padding, factor, bias=True):
        super().__init__()
        self.factor = factor
        self.conv = nn.Sequential(
                nn.ReflectionPad2d(padding),
                nn.Conv2d(input_channel, input_channel*4, kernel_size, stride=1, padding=0, bias=bias),
                nn.PixelShuffle(2)
        )

    def forward(self, x):
        return self.conv(x)

class decoder(nn.Module):
    def __init__(self, nc):
        super(decoder, self).__init__()

        # decoder
        self.DB2 = ConvBlock(nc, nc//2, kernel_size=3, stride=1, padding=1, bias=True)
        self.DB3 = ConvBlock(nc//2+nc//4, nc//4, kernel_size=1, stride=1, padding=0, bias=True)
        self.DB4 = ConvBlock(nc//4+nc//8, nc//8, kernel_size=1, stride=1, padding=0, bias=True)

        self.up1_2 = deconv(nc, nc//2, kernel_size=3, padding=1, factor=2)
        self.up2_3 = deconv(nc//2, nc//4, kernel_size=3, padding=1, factor=2)
        self.up3_4 = deconv(nc//4, nc//8, kernel_size=3, padding=1, factor=2)
        self.up1_3 = deconv(nc, nc//4, kernel_size=3, padding=1, factor=4)
        self.up2_4 = deconv(nc//2, nc//8, kernel_size=3, padding=1, factor=4)

    def forward(self, x1):


        x2 = self.DB2(F.interpolate(x1, scale_factor=2, mode='bilinear', align_corners=True))

        x3 = self.DB3(torch.cat([self.up1_3(x1), F.interpolate(x2, scale_factor=2, mode='bilinear', align_corners=True)],1))

        x4 = self.DB4(torch.cat([self.up2_4(x2), F.interpolate(x3, scale_factor=2, mode='bilinear', align_corners=True)],1))

        return x4

class Decoder(nn.Module):
    def __init__(self, nc):
        super(Decoder, self).__init__()

        # decoder
        self.DB2 = ConvBlock(nc, nc//2, kernel_size=3, stride=1, padding=1, bias=True)
        self.DB3 = ConvBlock(nc//2+nc//4, nc//4, kernel_size=1, stride=1, padding=0, bias=True)
        self.DB4 = ConvBlock(nc//4+nc//8, nc//8, kernel_size=1, stride=1, padding=0, bias=True)

        self.up1_2 = deconv2(nc, kernel_size=3, padding=1, factor=2)
        self.up2_3 = deconv2(nc//2, kernel_size=3, padding=1, factor=2)
        self.up3_4 = deconv2(nc//4, kernel_size=3, padding=1, factor=2)
        self.up1_3 = deconv(nc, nc//4, kernel_size=3, padding=1, factor=4)
        self.up2_4 = deconv(nc//2, nc//8, kernel_size=3, padding=1, factor=4)

    def forward(self, x1):

        x2 = self.DB2(self.up1_2(x1))
        x3 = self.DB3(torch.cat([self.up1_3(x1), self.up2_3(x2)],1))
        x4 = self.DB4(torch.cat([self.up2_4(x2), self.up3_4(x3)],1))

        return x4

class model(nn.Module):
    def __init__(self, input_nc1=1, input_nc2=4, ngf=32, n_downsampling=3):
        super(model, self).__init__()
        patchsize = [(32, 32), (16, 16), (8, 8), (4, 4)]

        mult = 2 ** (n_downsampling)
        out_channels = ngf * mult
        self.split_out_channels = split_layer(out_channels, 2)
        self.manipulate = Siamtrans(out_channels, patchsize)
        self.inlayer1 = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(input_nc1, ngf, kernel_size=3, padding=0),
            nn.LeakyReLU(0.2, True))

        self.inlayer2 = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(input_nc2, ngf, kernel_size=3, padding=0),
            nn.LeakyReLU(0.2, True))

        self.encoder = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(ngf, 64, kernel_size=3, stride=2, padding=0),  # s=2
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=0),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=0),  # s=2
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=0),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=0),  # s=2
            nn.LeakyReLU(0.2, inplace=True),
            nn.ReflectionPad2d(1),
            nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=0),
            nn.LeakyReLU(0.2, inplace=True)
        )


        self.decoder1 = Decoder(256)
        self.decoder2 = Decoder(128)
        self.decoder3 = Decoder(256)
        self.decoder4 = Decoder(128)
        self.decoder5 = Decoder(128)

        self.pan_real_out = nn.Sequential(
            nn.ReflectionPad2d(1), nn.Conv2d(ngf, 1, kernel_size=3, padding=0), nn.LeakyReLU(0.2, True)
        )
        self.pan_fake_out = nn.Sequential(
           nn.ReflectionPad2d(1), nn.Conv2d(ngf//2, 1, kernel_size=3, padding=0), nn.LeakyReLU(0.2, True)
        )
        self.ms_real_out = nn.Sequential(
            nn.ReflectionPad2d(1), nn.Conv2d(ngf, 4, kernel_size=3, padding=0), nn.LeakyReLU(0.2, True)
        )
        self.ms_fake_out = nn.Sequential(
           nn.ReflectionPad2d(1), nn.Conv2d(ngf//2, 4, kernel_size=3, padding=0), nn.LeakyReLU(0.2, True)
        )
        self.gt_fake_out = nn.Sequential(
            nn.ReflectionPad2d(1), nn.Conv2d(ngf//2, 4, kernel_size=3, padding=0), nn.LeakyReLU(0.2, True)
        )
        self.conv1 = nn.Conv2d(256, 128, kernel_size=1, padding=0)
        self.conv2 = nn.Conv2d(256, 128, kernel_size=1, padding=0)
        self.conv3 = nn.Conv2d(256, 128, kernel_size=1, padding=0)
        self.conv4 = nn.Conv2d(256, 128, kernel_size=1, padding=0)
    def forward(self, ms, pan):
        pan_in = self.inlayer1(pan)
        panfea = self.encoder(pan_in)

        ms_in = self.inlayer2(ms)
        msfea = self.encoder(ms_in)

        pan1 = self.conv1(panfea)
        pan2 = self.conv2(panfea)
        ms1 = self.conv3(msfea)
        ms2 = self.conv4(msfea)

        pan_real1, pan_fake, ms_real, ms_fake, gt_fuse = self.manipulate(pan1, pan2, ms1, ms2, panfea, msfea)

        pan_real = self.decoder1(pan_real1)
        pan_fake = self.decoder2(pan_fake)
        ms_real = self.decoder3(ms_real)
        ms_fake = self.decoder4(ms_fake)
        gt_fuse = self.decoder5(gt_fuse)

        pan_real = self.pan_real_out(pan_real)
        pan_fake = self.pan_fake_out(pan_fake)
        ms_real = self.ms_real_out(ms_real)
        ms_fake = self.ms_fake_out(ms_fake)
        gt_fuse = self.gt_fake_out(gt_fuse)

        return pan_real, pan_fake, ms_real, ms_fake, gt_fuse, pan1, pan2, ms1, ms2

